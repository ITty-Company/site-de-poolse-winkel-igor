# COPY — De Poolse Winkel Igor (Waalwijk)

Rol: copywriter · input: BRIEF.md, STORY.md · taal: Nederlands, met korte Poolse accenten (Zapraszamy!, Smacznego, Dzień dobry).
Alleen feiten uit BRIEF: **De Poolse Winkel Igor · Mendelssohnstraat 96, Waalwijk · 06 30 56 21 99.** Geen openingstijden, geen prijzen, geen merken, geen reviews, geen oprichtingsjaar, geen eigenaarsverhaal, geen bezorging, geen e-mail, geen social media. Assortiment = voorbeeld, altijd met label. Kiszenie = algemeen Pools keukenambacht, geen claim over wat de winkel verkoopt.

Links (voor builder):
- `TEL` = tel:+31630562199
- `ROUTE` = https://www.google.com/maps/search/?api=1&query=Mendelssohnstraat+96+Waalwijk
- `WA` = https://wa.me/31630562199 — alleen tonen met label «nog te bevestigen» (`WA_CONFIRMED=false`)

---

## Gedeeld (alle pagina's)

**Logo-tekst:** De Poolse Winkel Igor · sub (mono): Poolse winkel · Waalwijk
**Navigatie:** Home · Winkel · Over de winkel · Contact · pil-knop: `Bel 06 30 56 21 99` → TEL · mandje-icoon met teller
**Mobiel menu, onderaan:** `Bel 06 30 56 21 99` · `Route plannen` · Mendelssohnstraat 96, Waalwijk
**Skip-link:** Naar inhoud
**Beeldlabels:** `Sfeerbeeld` · op productfoto's: `Sfeerbeeld · voorbeeld` · over-ons hero: `Sfeerbeeld — niet de echte gevel`
**Overgangsgordijn («deksel»):** home. · winkel. · over de winkel. · contact.
**Demo-plaatje (vast, linksonder, klein glas):** Ontwerpvoorstel — ITty Company

**Finale (onderaan elke pagina, op K12)**
- h2: **Tot zo, om de hoek.**
- PL-accent (Young Serif, klein, boven h2): *Zapraszamy!*
- tekst: Mendelssohnstraat 96 in Waalwijk. Loop binnen, kijk rustig rond en vraag gerust wat er vandaag op de plank staat. Liever eerst even bellen? Ook goed.
- knoppen: `Bel 06 30 56 21 99` → TEL · `Route plannen` → ROUTE · `WhatsApp` → WA (onder de knop mono-label: *nog te bevestigen*)

**Footer**
- De Poolse Winkel Igor · Mendelssohnstraat 96, Waalwijk · 06 30 56 21 99
- Openingstijden: volgen binnenkort — bel gerust even.
- Home · Winkel · Over de winkel · Contact
- **Ontwerpvoorstel — ITty Company.** Alle beelden zijn sfeerbeelden, gemaakt voor dit voorstel; ze tonen niet de echte winkel of het actuele assortiment. Assortiment en bestellen zijn ter illustratie en worden door de eigenaar aangevuld.

**Meta**
- index title: De Poolse Winkel Igor — Poolse winkel aan de Mendelssohnstraat in Waalwijk
- index description: Poolse producten om de hoek in Waalwijk. De Poolse Winkel Igor, Mendelssohnstraat 96. Bel 06 30 56 21 99 of kom langs.
- winkel title: De winkel — Poolse producten bij De Poolse Winkel Igor, Waalwijk
- over-ons title: Over de winkel — De Poolse Winkel Igor, Waalwijk
- contact title: Contact & route — De Poolse Winkel Igor, Mendelssohnstraat 96, Waalwijk

---

## HOME (`index.html`)

### Hero (over K1, vóór het scrollen)
- chip: Poolse winkel · Waalwijk
- h1: **De Poolse Winkel Igor**
- lead: Een stukje Poolse keuken in Waalwijk. Aan de Mendelssohnstraat 96 — gewoon om de hoek.
- PL-accent onder lead (klein): *Dzień dobry!*
- knoppen: `Bel 06 30 56 21 99` (accent) · `Route plannen` (contour)
- glazen plaatjes: `Mendelssohnstraat 96` · `06 30 56 21 99` · `Openingstijden volgen`
- scroll-hint (mono): scroll — zo ontstaat een pot ogórki

### Film — regels per beat (h2 + onderschrift, verschijnen alleen op het rustpunt)
| # | h2 | onderschrift (mono) | groot Pools woord |
|---|---|---|---|
| 1 | Eerst een lege pot. | Zo begint elke Poolse voorraadkast. | słoik |
| 2 | Dan de komkommers. | Klein, stevig en rechtop tegen elkaar. | ogórki |
| 3 | Dille, knoflook, mosterdzaad. | Wat erbij hoort, valt er vanzelf in. | koper |
| 4 | Zout water. Verder niets. | Geen azijn: de pekel doet het werk. | solanka |
| 5 | Deksel erop. | Nu is het aan de tijd. | czas |
| 6 | Zo smaakt geduld. | Ogórki kiszone — vraag in de winkel wat er staat. | kiszone |

### Film — kaartjes (één per beat, `fcard`: kop + alinea)
1. **Een pot bij het raam** — In bijna elke Poolse keuken staat er wel een: een glazen pot op de vensterbank of onder in de kast. Leeg is hij een belofte. Over een paar dagen staat er iets in dat je nergens anders zo proeft.
2. **Klein en stevig** — Voor ogórki kiszone kies je kleine, stevige komkommers met een dun velletje. Ze gaan rechtop de pot in, dicht tegen elkaar, zodat ze straks niet gaan drijven en overal even goed in de pekel staan.
3. **Wat erbij hoort** — Schermen dille met zaad, een paar tenen knoflook, een blad mierikswortel voor de knapperigheid en een handje mosterdzaad. Elke keuken heeft zijn eigen mengsel; het idee blijft hetzelfde: eenvoudig, en vol smaak.
4. **Alleen zout en water** — Dit is geen augurk uit het zuur. Er komt geen azijn bij te pas. Het zoute water en de tijd doen samen het werk: de komkommers worden vanzelf zuur, fris en een beetje bruisend.
5. **Dicht en wachten** — Deksel erop en laten staan. In de pot gebeurt het rustig: kleine belletjes stijgen op, de pekel wordt troebel, de groene kleur verandert langzaam. Haasten heeft geen zin.
6. **Zuur, fris, knapperig** — Na een paar dagen zijn ze olijfgroen en heerlijk zuur. Bij een boterham, bij aardappels, bij soep — of zomaar uit de pot. Welke potten er bij Igor op de plank staan, hoor je in de winkel. — knop: `Bekijk de winkel` → winkel.html · `Bel 06 30 56 21 99` → TEL

### Act 2 — «Op de plank» (over K7)
- h2: **Op de plank, om de hoek.**
- Je hoeft niet zelf te wachten tot een pot klaar is. In een Poolse winkel staan de potten en blikken in rijen naast elkaar, met daaronder het brood en verderop wat je voor het avondeten nodig hebt. Voor wie uit Polen komt is het een stukje thuis. Voor de buren uit Waalwijk is het een plek om iets nieuws te proeven.
- De Poolse Winkel Igor vind je aan de Mendelssohnstraat 96 in Waalwijk. Een winkel om de hoek: je loopt binnen, kijkt rond en vraagt wat er is.
- knop: `Naar de winkel` → winkel.html

### Journaal J1 — «Wat is kiszenie?» (donkere dilleband)
- PL-kop klein: *kiszenie*
- h2: **Zuur zonder azijn.**
- Kiszenie is de Poolse manier om groente te bewaren: in zout water, met kruiden, en dan vooral wachten. Melkzuurbacteriën die van nature op de groente zitten, zetten de suikers om in zuur. Zo worden komkommers, kool of bieten frisser, zuurder en langer houdbaar, zonder dat er azijn aan te pas komt.
- Daarom smaakt een echte ogórek kiszony anders dan een augurk uit een Nederlandse pot. Minder scherp, ronder, met een licht bruisend randje. De pekel zelf wordt ook gedronken: veel Polen zweren erbij, koud uit de koelkast.
- Het bekendste voorbeeld is zuurkool — kapusta kiszona — de basis van bigos. Maar ook in soep proef je het: żurek en ogórkowa danken hun frisse smaak aan hetzelfde idee. Eenvoudig, oud, en nog altijd in bijna elke Poolse keuken te vinden.
- **Pekelklok** (interactief, slider) — labels: `vers` · `licht zuur` · `kiszone` · onderschrift: *Ter illustratie. Hoe lang iets staat, verschilt per pot en per keuken.*

### Journaal J2 — «Een winkel om de hoek» (paperband)
- h2: **Een winkel om de hoek.**
- Een Poolse winkel is meer dan een schap met andere etiketten. Het is de plek waar je het brood vindt dat je van thuis kent, waar je een praatje maakt bij de kassa en waar je de ingrediënten haalt voor het gerecht van je oma.
- Voor wie hier woont en werkt en Polen mist, is zo'n winkel in de buurt goud waard. En voor iedereen die nieuwsgierig is: loop gerust binnen. Vraag wat iets is, hoe je het eet, wat je erbij neemt. Proeven is de snelste manier om een keuken te leren kennen.
- Zo'n winkel heeft meestal brood en gebak, vleeswaren en worst, zuivel zoals twaróg, potten en blikken voor de voorraadkast, snoep en koek, en iets te drinken. Wat De Poolse Winkel Igor precies verkoopt, vult de eigenaar hier zelf aan.
- Lopende band: brood · vleeswaren · zuivel · potten & blikken · snoep · dranken — *voorbeeld, door de eigenaar aan te vullen*

### Journaal J3 — «Smaakkompas»
- h2: **Waar heb je zin in?**
- intro: Kies een smaak en kijk wat er in een Poolse keuken bij past. Alles hieronder is een voorbeeld; wat er echt op de plank staat, zie je in de winkel.
- **zuur** — Ingelegde komkommers, zuurkool, bietjes in het zuur. Fris naast iets hartigs.
- **zoet** — Karamelsnoepjes, koeken met maanzaad, honing. Bij de koffie of de thee.
- **hartig** — Gerookte worst, roggebrood, een stevige soep. Voor een echte Poolse lunch.
- **vers** — Twaróg (Poolse kwark), brood, dille. De basis van het ontbijt.
- knop: `Kijk in de winkel` → winkel.html?smaak=…

(Finale + footer: zie Gedeeld.)

---

## WINKEL (`winkel.html`)

### Film-hero (W1+W2) — regels
| # | h2 | onderschrift |
|---|---|---|
| 1 | Op de plank. | Potten, blikken en wat je voorraadkast nodig heeft. |
| 2 | Brood erbij. | Rond, donker, met maanzaad. |
| 3 | En wat je verder zoekt. | Voor de boterham, de soep en het toetje. |

### Intro
- h1 (sr-only op film, zichtbaar boven catalogus): **De winkel.**
- lead: Blader door een voorbeeld van wat je in een Poolse winkel vindt, zet het in je mandje en maak er een boodschappenbriefje van. Zo weet je straks precies wat je wilt vragen.
- glazen balk (mono): **Voorbeeldassortiment — door de eigenaar aan te vullen.** Geen prijzen: die hoor je in de winkel.

### Categorieën (tabs) en voorbeeldproducten
Elk product: naam · één regel · `prijs in de winkel` · smaak-tag. Allemaal *voorbeeld*.
**Brood & gebak**
- Roggebrood — Donker, stevig en een beetje zuur. Lekker met boter en dille. *(hartig)*
- Maanzaadbrood — Gevlochten brood met maanzaad. *(zoet)*
- Kaiserbroodjes — Knapperige ronde broodjes voor bij het ontbijt. *(vers)*
**Vleeswaren**
- Gerookte worst — Een ring kiełbasa, voor op brood of in de pan. *(hartig)*
- Ham en vleeswaren — Voor de boterham. *(hartig)*
**Zuivel**
- Twaróg — Poolse kwark, kruimelig en fris; zoet of hartig te eten. *(vers)*
- Zure room — Voor soep, pierogi en salade. *(vers)*
**Potten & blikken**
- Ogórki kiszone — Komkommers uit de pekel, zonder azijn. *(zuur)*
- Zuurkool — De basis voor bigos. *(zuur)*
- Rode bietjes — Geraspt of in plakjes, voor bij het warme eten. *(zuur)*
**Snoep & koek**
- Krówki — Zachte karamelsnoepjes in papiertjes. *(zoet)*
- Koekjes en wafels — Voor bij de koffie. *(zoet)*
**Dranken**
- Kompot en sappen — Vruchtendrank zoals thuis. *(zoet)*
- Kwas — Gegist drankje van brood. *(zuur)*
Onder elke tab, mono: *Voorbeeld — door de eigenaar aan te vullen.*

### Mandje & afronden (demo)
- knop op kaart: `In mandje` · toast: *Toegevoegd aan je mandje.*
- mandje-kop: **Je mandje** · leeg: *Nog niets in je mandje. Kijk rustig rond.*
- totaalregel: *{n} producten · prijzen volgen in de winkel*
- keuze: `Afhalen in de winkel` (standaard) · `Bezorgen` — *alleen als de winkel dit aanbiedt (nog te bevestigen)*
- velden: Naam · Telefoonnummer · Wanneer wil je langskomen? (vrij veld) · Opmerking
- knop: `Betalen met iDEAL — demo` → modaal: **Dit is een ontwerpvoorstel.** Er wordt niets betaald en niets verstuurd. Zodra de winkel online bestellen wil, zetten we dit echt aan.
- **Boodschappenbriefje** — kop: *Je briefje* · knoppen: `Kopieer` · `Bel de winkel` → TEL · `Stuur via WhatsApp` (*nog te bevestigen*) · toast na kopiëren: *Gekopieerd. Neem het mee of lees het voor aan de telefoon.*
- placeholderblok (stippellijn): *Hier komen foto's van de echte schappen van De Poolse Winkel Igor.*

---

## OVER DE WINKEL (`over-ons.html`)

### Film-hero (O1) — regels
| # | h2 | onderschrift |
|---|---|---|
| 1 | Een gewone straat in Waalwijk. | Bakstenen huizen, fietsen tegen de muur. |
| 2 | En daar, achter het raam: potten. | Sfeerbeeld — niet de echte gevel. |

### J — «Een stukje Polen om de hoek» (paper)
- h2: **Een stukje Polen om de hoek.**
- De Poolse Winkel Igor vind je aan de Mendelssohnstraat 96 in Waalwijk. Een buurtwinkel werkt anders dan een grote supermarkt. Je komt er niet voor een volle kar, maar voor dat ene brood, die ene pot, dat ene ding dat je mist.
- In Nederland wonen en werken veel mensen uit Polen, ook in de regio rond Waalwijk. Voor hen is een Poolse winkel een vertrouwd adres: bekende smaken, bekende verpakkingen, een bekende taal. Voor Nederlanders is het precies andersom — een kleine reis zonder dat je de stad uit hoeft.
- Daarom is dit voorstel gebouwd rond één pot ogórki kiszone. Niet omdat dat het enige is wat er staat, maar omdat het laat zien waar de Poolse keuken om draait: eenvoudige ingrediënten, zout, tijd en geduld. *Smacznego.*

### Lijn-proces (SVG tekent mee) — stappen
binnenlopen → rondkijken → vragen wat er is → afrekenen → smacznego

### «Het verhaal van Igor» (donkere band, eerlijke placeholder)
- h2: **Het verhaal van de winkel.**
- tekst: Dit stuk vertelt de eigenaar zelf. Hoe de winkel begon, wie er achter de toonbank staat en wat je echt moet proberen — dat schrijven we samen, zodra we elkaar gesproken hebben.
- drie lege etiketten: `Sinds wanneer?` · `Wie staat er achter de toonbank?` · `Wat mag je niet missen?`
- mono onderschrift: *Wordt ingevuld na overleg met de eigenaar.*

---

## CONTACT (`contact.html`)
- PL-accent: *Zapraszamy!*
- h1: **Kom langs.**
- lead: De Poolse Winkel Igor vind je aan de Mendelssohnstraat 96 in Waalwijk. Bellen kan altijd: 06 30 56 21 99.
- glazen kaarten:
  - **Adres** — Mendelssohnstraat 96, Waalwijk · knop `Route plannen`
  - **Telefoon** — 06 30 56 21 99 · knop `Bel nu`
  - **WhatsApp** — 06 30 56 21 99 · *nog te bevestigen*
  - **Openingstijden** — Volgen binnenkort. Bel gerust even, dan hoor je meteen of we open zijn.
- kaart-onderschrift: *Schematische kaart.* · knop `Open in Google Maps`
- **Vragen**
  - *Kan ik vooraf bestellen of iets laten klaarzetten?* — Bel even naar 06 30 56 21 99, dan hoor je wat er kan.
  - *Hoe laat zijn jullie open?* — De openingstijden komen hier binnenkort te staan. Tot die tijd: bel gerust.
  - *Ik spreek geen Pools — is dat een probleem?* — Vraag het gerust in de winkel; wijzen en proeven werkt ook altijd.
  - *Hebben jullie product X?* — Het assortiment op deze site is een voorbeeld. Bel of loop binnen, dan weet je het zeker.

## 404
- h1: **Deze pagina staat niet op de plank.**
- tekst: Misschien is hij verplaatst. Kijk in de winkel of ga terug naar het begin.
- knoppen: `Naar home` · `Naar de winkel`

---
Woordtelling (richtwaarde): home ≈ 1.000 woorden (film + kaartjes + journaal), site totaal ≈ 2.100. Alle claims gecontroleerd tegen BRIEF: adres, telefoon, naam — de rest is algemeen keukenambacht of gelabeld voorbeeld.
