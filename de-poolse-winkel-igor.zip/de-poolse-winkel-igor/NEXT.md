# NEXT — De Poolse Winkel Igor · что делать в следующем цикле
Статус: **пре-продакшн готов** (BRIEF, PALETTE, TYPE, STORY, COPY). Ничего не собрано, картинки/видео не генерировались. Журналы: строки «(в работе)» добавлены в `journal/palettes.md` и `journal/fonts.md`.

## 0. До старта (оркестратор)
- [ ] `leads/leads.csv`: найти/добавить строку `De Poolse Winkel Igor` (источник supermarkt-in.nl/waalwijk/de-poolse-winkel-igor), статус `в работе` — в этом пре-продакшне leads.csv НЕ трогали.
- [ ] HANDOFF.md — дописать, что сайт в работе (в начале цикла).
- [ ] Вопросы клиенту из BRIEF «Открытые вопросы» — передать Анастасии (особенно: часы, WhatsApp, индекс, ассортимент).

## 1. Ключевые кадры (Higgsfield gpt_image_2_6, ≤ 14)
- [ ] Генерировать строго по STORY §8, цепочкой с `medias` = предыдущий кадр: K1 → K2 → K3 → K4 → K5 → K6 → K7 → K8 → K9 → K13; K10 (ref K1) → K11; K12 (ref K6 + K11). Резерв R — только на переделку (скорее всего K4 со струёй).
- [ ] Каждый кадр — посмотреть глазами: та же банка (форма/высота/без этикетки), чеснок+укроп+эмалевая мисочка на подоконнике на месте, нет рук/инструментов/кувшина/текста, у K1–K6 окно и подоконник совпадают (±3 %); иначе выровнять кропом.
- [ ] Сохранить в `sites/de-poolse-winkel-igor/kf/` (webp 1920×1080 q≈80) + мобильные кропы 1080×1920 (центр банки: K1 x 38 %, K2–K6 x 55 %, K7 центр, K12 x 30 %).
- [ ] Если кредиты Higgsfield кончились — локальные кадры на Mac, отметить в отчёте.

## 2. Клипы LTX (Mac, по одному, nice + caffeinate, 960×544, 121 кадр)
- [ ] F1 K1→K2, F2 K2→K3, F3 K3→K4, F4 K4→K5, F5 K5→K6, W1 K7→K8, W2 K8→K9, O1 K10→K11, C1 K12→K12 — промпты: STORY §2 (движение) + «Empty bright scene, nothing enters the frame except what falls or pours from above, no people.» + NEG из STORY §2. Шаблон запуска: `sites/dn-bebbes-v2/clips/run.sh`.
- [ ] Каждый клип — лист 8 кадров `ffmpeg -i X.mp4 -vf "select=not(mod(n\,15)),tile=4x2" -frames:v 1 sheet.jpg` → Read. Брак (руки, лишняя банка, «плавится» стекло, текст, скачок) → `SEED_BASE=30`, макс. 4 попытки, потом упростить промпт / запасной вариант F3–F4 кодом (STORY §2).
- [ ] Склейка: film-main.mp4 (F1–F5, 25 с), film-winkel.mp4 (W1+W2), film-over.mp4 (O1), loop-contact.mp4 (C1 pingpong); `-g 1`, desktop 1280 + mobile 9:16; главная ≤ 15 МБ.

## 3. Builder
- [ ] Скопировать основу `sites/dn-bebbes/assets/site.js`, `style.css`, `shop.js` и `_notes/build.py` → `sites/de-poolse-winkel-igor/` и сменить: палитру (PALETTE tokens), шрифты (TYPE), главы (COPY «Film — regels» + «kaartjes»), страницы (index, winkel, over-ons, contact, 404).
- [ ] Новое относительно dn-bebbes (обязательно, иначе сайт будет клоном):
  - HUD `KISZENIE · 01 / 06` моно справа вверху + `.bigword` польское слово за банкой;
  - портал «bubbles» (WebGL, пузырьки рассола) после фильма → act 2 K7;
  - интерактив «Pekelklok» (слайдер скрабит F5) на тёмной ленте J1;
  - Smaakkompas (4 «крышки») + фильтр `?smaak=` в winkel;
  - витрина без цен: `prijs in de winkel`, итог `prijzen volgen in de winkel`, «Boodschappenbriefje» (copy / tel / WhatsApp с пометкой), модал iDEAL-демо;
  - переход страниц «deksel» (ирис + поворот насечек крышки);
  - `WA_CONFIRMED=false` → кнопки WhatsApp с моно-пометкой «nog te bevestigen».
- [ ] Светлый мир (§0a): фон `--light`, текст `--dark`, акцент только заливкой. Тёмная лента — максимум одна на страницу. Фоны секций все разные (light / paper / dark / K7 / K12).
- [ ] Подписи `Sfeerbeeld` крепить к самому кадру (`.cap` внутри фигуры), прятать, когда кадр ушёл в затемнение (замечание dn-bebbes r2).
- [ ] Проверить польские глифы в Young Serif / Work Sans / Plex Mono (строка в TYPE.md).
- [ ] `python3 tools/check_site.py sites/de-poolse-winkel-igor` — 0 ошибок консоли, без overflow, вес.

## 4. Critic (≥ 9/10, макс. 4 раунда, рубрика SCROLL_FILM_PROMPT §4)
Особо проверить:
- [ ] **Отличие от Warta** (STORY §0 таблица): ни ночи, ни корзины, ни красного, ни NL/PL-переводов-интерактива. Поставить рядом скриншоты `warta-supermarkt-screens.jpg`.
- [ ] Стыки F1–F5 не видны; банка не меняет форму; жидкость в F3–F4 не «плавит» стекло (урок asya r4: деформированный объект = максимум 5).
- [ ] Главы стоят на битах: «Zout water.» — когда в кадре льётся рассол, «Deksel erop.» — когда крышка.
- [ ] Честность: нет часов, цен, брендов, отзывов, года, истории владельца, «bezorgen» как факта; WhatsApp помечен; ассортимент везде «voorbeeld»; Igor не описан как человек.
- [ ] Mobile 390: вертикальный фильм, главы читаются на стекле, CTA в зоне большого пальца, корзина-drawer удобна.

## 5. Сдача (только при ≥ 9)
- [ ] Видео прокрутки `sites/de-poolse-winkel-igor-demo.mp4` (главная + переход на winkel), zip, `python3 tools/deliver.py de-poolse-winkel-igor`, дубль в Telegram (`tools/tg_send.py`), отчёт `reports/<дата>-de-poolse-winkel-igor.md`, в журналах заменить «(в работе)» на финальное, leads.csv → `демо готово` + «что сказать клиенту» из BRIEF.
