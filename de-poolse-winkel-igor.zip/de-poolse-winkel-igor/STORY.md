# STORY — De Poolse Winkel Igor (Waalwijk) · SHOT LIST

Роль: story-architect · вход: BRIEF.md, PALETTE.md («Ogórek w słońcu»: light #DEEBBF · paper #F6F8EA · dark #25401E · accent #E39B12), TYPE.md (Young Serif 400 + Work Sans 400 + IBM Plex Mono 500).
Главное правило: `references/SCROLL_FILM_PROMPT.md` (SCROLL FILM, светло и разно §0a) > `DESIGN_STANDARD.md` (из «★ ГЛАВНЫЙ СТИЛЬ» берём: честность, ≥ 4 страницы, движение везде, без стыков; онлайн-витрина с корзиной). Образец механики и структуры: `sites/dn-bebbes` (+ `_notes/build.py`: `film(src, poster, chapters)` с полями t / s / fx / dy / h / p / cta). Урок `asya-bakkerij` (5/10 из-за большого движения камеры, где ИИ «переплавил» объекты): **соседние ключевые кадры — почти одинаковые, одна камера, одна поверхность; большие смены сцены — только кодом-порталом, не морфом.**
Дата: 19.11.2026

---

## 0. Идея в одной фразе
**Een lege glazen pot op een zonnige vensterbank vult zich vanzelf — komkommers, dille, knoflook, mosterdzaad, zout water — en rijpt in het licht van één dag tot ogórki kiszone; daarna staat hij op de plank van de winkel aan de Mendelssohnstraat.**

**ГЛАВНЫЙ ОБЪЕКТ: стеклянная банка (słoik) с ogórki kiszone** — сердце польской кладовки и самый узнаваемый «польский вкус» для голландца. Процесс kiszenie (квашение в рассоле без уксуса) — это настоящий процесс «как в эталоне пиццы/шаурмы»: всё падает и льётся само, рук нет, предметы, за которые держат, не нужны.

Почему банка, а не «корзина/продукты собираются» (как разрешено для супермаркета): ровно это уже сделано у Warta. Мы не утверждаем, что Igor продаёт именно эти огурцы: банка — **символ польской кухни** (Sfeerbeeld), а ассортимент на сайте — «Voorbeeldassortiment — door de eigenaar aan te vullen».

### Чем этот сайт ЯВНО отличается от `sites/warta-supermarkt` (обязательно для builder/critic)
| | Warta | Igor |
|---|---|---|
| Мир | ночь, туман над рекой, один красный свет | **день**: утро → золотой час одного солнечного дня, подоконник, стекло, вода |
| Объект | плетёная корзина, наполняется продуктами | **стеклянная банка**, процесс квашения (огурцы → укроп → рассол → крышка → время) |
| Палитра | ink navy + ivory + red | светло-зелёный рассол + укроп + горчичное золото |
| Шрифт | Sora 300 строчный гротеск | Young Serif (этикетка) + IBM Plex Mono (HUD) |
| Механика | sticky-кадры, кроссфейды, панели слева | **scroll film** (LTX-клипы, скраб video.currentTime), HUD «kiszenie · 03/06», портал-пузырьки |
| Интерактив | NL/PL-переключатель, «słowo/woord», список покупок | **«pekelklok»** (слайдер времени квашения), **витрина с корзиной + smaakkompas**, «boodschappenbriefje» |
| Переход страниц | шторка + силуэт корзины + красная лампа | **«deksel»**: круглая ирис-шторка, которая закручивается как крышка банки |
| Финал | корзина на пороге мокрой ночной улицы | вид изнутри магазина через окно с банкой на солнечную улицу |
Запрещено переносить у Warta: польские большие слова-переводы как интерактив, корзину, красный свет, ночь, реку.

### Правило честности (copywriter + builder)
- Подтверждено только: **De Poolse Winkel Igor · Mendelssohnstraat 96, Waalwijk · 06 30 56 21 99**. Больше нет фактов.
- Все кадры — сгенерированы: подпись `Sfeerbeeld` (места, банка, полки) моно 11px `--muted`, прикреплена к кадру (не висит в пустоте — замечание критика dn-bebbes r2). Людей в кадрах нет вообще.
- Ассортимент: только типичные категории польского магазина с пометкой `Voorbeeldassortiment — door de eigenaar aan te vullen`. Без брендов, без цен (вместо цены — `prijs in de winkel`), без «vers elke dag», без «bezorgen» как факта.
- Часы: `Openingstijden volgen` (заглушка) + кнопка «Bel even» — никакого «nu open».
- WhatsApp: кнопка только с пометкой `WhatsApp — nog te bevestigen` и флагом `data-confirm="wa"` (builder: одна константа `WA_CONFIRMED=false` → кнопка видна в демо с пометкой; когда клиент подтвердит — пометка исчезает).
- Igor — только часть названия. Никаких «Igor staat elke dag…», «sinds 20xx», «familiebedrijf».
- Kiszenie описываем как общее ремесло польской кухни (соль + вода + укроп + чеснок, без уксуса, молочнокислое брожение, несколько дней) — общеизвестно, без цифр-обещаний.

---

## 1. Маршрут камеры (Home)
*порог → путь → объект крупно → внутрь объекта → результат → свет/финал* (§1 мастер-промпта), здесь — **время одного дня** вместо полёта по городу:
**утро, пустая банка у окна → огурцы падают внутрь → укроп и чеснок сыплются сверху → льётся рассол, солнце играет в воде → крышка → свет уходит в золотой час, огурцы становятся оливковыми → (портал: пузырьки рассола) → банка уже на полке магазина → (журнал) → финал: вид из окна магазина на улицу.**
Камера внутри фильма №1 движется медленно и непрерывно (push-in + чуть ниже), без резких смен; композиция меняется постепенно: K1 широкий кадр (банка слева на 38 %), K3–K6 банка крупно по центру-право; K7 (второй акт) — фронтальная симметрия полки; K10–K11 — уличная перспектива; K12 — силуэт банки на окне против света. Формула «объект справа + пустота слева» — не используется.

## 2. ФИЛЬМЫ (Режим A-local: LTX на Mac, `tools/ltx_flf.py`, по одному клипу, 960×544 → апскейл не нужен для скраба, 121 кадр, nice+caffeinate)
Общий NEG для всех клипов:
`hands, fingers, arms, people, person, human, face, knife, spoon, ladle, jug, tools, label, text, letters, logo, watermark, deformed jar, melting glass, duplicate objects, extra jars, morphing, cuts, jittery, blurry, worst quality`

| Клип | from → to | Движение камеры (1 предложение) | Что меняется | Страница / % фильма |
|---|---|---|---|---|
| F1 | K1 → K2 | slow continuous push-in toward the jar, no cuts | маленькие огурцы падают сверху в банку и встают вертикально, плотно | index · 0–20 % |
| F2 | K2 → K3 | push-in continues, camera lowers slightly to jar mid-height | сверху падают зонтики укропа, зубчики чеснока, лист хрена, сыплются горчичные зёрна | index · 20–40 % |
| F3 | K3 → K4 | almost static, very slow push-in | прозрачная струя рассола льётся сверху из-за кадра, банка наполняется до половины, пузыри, солнечные блики-каустики бегут по подоконнику | index · 40–60 % |
| F4 | K4 → K5 | very slow pull-back of 3–5 % | рассол доходит до горлышка, струя иссякает, сверху опускается простая металлическая крышка и садится, на стекле лёгкий конденсат | index · 60–80 % |
| F5 | K5 → K6 | static camera, tiny orbit to the right | time-lapse: солнечный свет и тени ползут по подоконнику от утра к золотому часу, огурцы темнеют до оливкового, рассол слегка мутнеет и светится золотом, поднимаются мелкие пузырьки | index · 80–100 % + слайдер «pekelklok» |
| W1 | K7 → K8 | slow lateral truck to the right along the shelf, no cuts | полка с банками сменяется полкой с хлебом | winkel.html hero-фильм |
| W2 | K8 → K9 | truck right continues, slight push-in | хлеб → край прилавка с колбасой, творогом, конфетами в бумаге | winkel.html hero-фильм |
| O1 | K10 → K11 | slow steady forward dolly down the pavement toward the shop window | улица приближается к витрине с банками | over-ons.html hero-фильм |
| C1 | K12 → K12 | locked-off camera, loop | тюль чуть колышется, пылинки в луче, на улице за стеклом медленно меняется свет | contact.html hero-loop (pingpong) |

Склейка: film-main.mp4 = F1+F2+F3+F4+F5 (25 с, 24 fps, `-g 1` all-intra, desktop 1280 / mobile 9:16 кроп по центру банки); film-winkel.mp4 = W1+W2 (10 с); film-over.mp4 = O1 (5 с); loop-contact.mp4 = C1 pingpong. Стык прыгает → взять последний кадр клипа как start следующего (§2.1 п.3). Каждый клип — лист 8 кадров (`select=not(mod(n\,15)),tile=4x2`) и проверка глазами: руки, лишние банки, «плавящееся» стекло, надписи → другой seed (max 4), потом упростить промпт.
**Запасной вариант** для F3/F4 (жидкость — риск): если LTX «плавит» банку — кадр держится (K3→K4 кроссфейд под canvas-водой: метаболлы-пузырьки поднимаются снизу, струя рисуется шейдером), как мука у asya r2.

## 3. Главы Home по битам (`film-main.mp4`, rest-позиции как у asya/dn-bebbes: текст виден только на плато вокруг `at`)
HUD справа вверху: `KISZENIE · 01 / 06` (моно), полоса прогресса снизу цвета `--accent`; слева снизу подпись сцены `Sfeerbeeld`. Большое польское слово (`.bigword`, opacity .07) за банкой, частично закрыто ею. Текст — в спокойной зоне кадра на локальной подложке `--shade` (не тёмный кадр).

| # | at | Кадр | Строка-глава (h2, COPY) | Подпись | bigword | fx (canvas) | Где текст | Фон/свет главы |
|---|---|---|---|---|---|---|---|---|
| 1 | 0 s | K1 пустая банка на подоконнике, утро | Eerst een lege pot. | Zo begint elke Poolse voorraadkast. | słoik | dust (пылинки в луче) | справа вверху, на небе в окне | прохладное утро, голубовато-зелёный |
| 2 | 5 s | K2 банка с огурцами | Dan de komkommers. | Klein, stevig en rechtop tegen elkaar. | ogórki | drops (капли воды с огурцов) | слева, на тюле | солнце выходит, ярче |
| 3 | 10 s | K3 + укроп, чеснок, хрен, горчица | Dille, knoflook, mosterdzaad. | Wat erbij hoort, valt er vanzelf in. | koper | seeds (падающие зёрна, accent) | слева вверху, на стене | тёплое пятно солнца на тюле |
| 4 | 15 s | K4 льётся рассол | Zout water. Verder niets. | Geen azijn: de pekel doet het werk. | solanka | bubbles + caustics | слева вверху | макро-блеск, каустики |
| 5 | 20 s | K5 крышка | Deksel erop. | Nu is het aan de tijd. | czas | glints (блики на стекле) | справа вверху | полный дневной свет |
| 6 | 25 s | K6 оливковые огурцы, золотой час | Zo smaakt geduld. | Ogórki kiszone — vraag in de winkel wat er staat. | kiszone | warm dust + rising bubbles | слева вверху | янтарный золотой час |
CTA на главе 6: `Bekijk de winkel` → winkel.html (кнопка-акцент) + контурная `Bel 06 30 56 21 99`.
Карточки поверх фильма (`fcard`, как dn-bebbes): по 1 на главу, h (≤ 6 слов) + 1 абзац ≤ 45 слов из COPY «Film — kaartjes».
Hero-слой (до скролла, поверх K1): лого-текст, чип `Poolse winkel · Waalwijk`, h1 `De Poolse Winkel Igor`, lead, 2 кнопки, 3 стеклянные плашки ТОЛЬКО факты: `Mendelssohnstraat 96` · `06 30 56 21 99` · `Openingstijden volgen`. Подсказка `scroll — zo ontstaat een pot ogórki`. При первом скролле hero растворяется, камера уже едет (F1).

**Мобильная (390):** тот же фильм 9:16 (кроп центр банки: K1 x≈38 %, K2–K6 x≈55 %), строка-глава снизу в нижней трети на стекле `--glass`, карточка свёрнута (h + 2 строки + «lees verder +»), HUD сверху мелко. CTA в зоне большого пальца.

## 4. После фильма (Home)
1. **Портал «bubbles»** (WebGL, §2.4 режим `drip`/`radial` в варианте пузырьков): из рассола K6 поднимаются пузыри (paper + accent-glow), заполняют экран светло-зелёным `--light`, из центра раскрывается K7. 100vh. Не crossfade.
2. **Act 2 — «Op de plank» (K7, sticky 200vh):** фронтальная полка, Ken Burns 1.00→1.06 + лёгкий параллакс от мыши; та же оливковая банка в центре. Поверх: h2 + 2 абзаца (COPY J2) + кнопка `Naar de winkel`. Подпись `Sfeerbeeld`.
3. **Журнал J1 «Wat is kiszenie?»** — единственная тёмная лента (`--dark` фон, `--paper` текст): 3 абзаца + **интерактив 1 «Pekelklok»**: слайдер `vers → licht zuur → kiszone` скрабит F5 (K5→K6), над ним моно-подписи; под ним мелко «Ter illustratie. Hoe lang iets staat, verschilt per pot en per keuken.» Стоп-кадры K3 и K4 (4:5) по краям с подписью `Sfeerbeeld`.
4. **Журнал J2 «Een winkel om de hoek»** — фон `--paper`: текст + **бегущая строка** (медленно, без наклона) категорий-примеров: `brood · vleeswaren · zuivel · potten & blikken · snoep · dranken` с моно-пометкой в конце строки `voorbeeld — door de eigenaar aan te vullen`. Текст «прокрашивается» по скроллу (muted → dark).
5. **Журнал J3 «Smaakkompas»** — фон `--light`: 4 круглых стеклянных «крышки» `zuur · zoet · hartig · vers`; тап → показывает 3 примера категорий из COPY (без брендов) + кнопка `Kijk in de winkel` (winkel.html?smaak=zuur). Это мостик в витрину.
6. **Финал** — фон K12 (вид изнутри: банка на окне, солнечная улица), Ken Burns, пылинки в луче (canvas). h2 + строка + кнопки `Bel 06 30 56 21 99` · `Route plannen` · (WhatsApp с пометкой). Затем футер.

## 5. Внутренние страницы (≥ 4 страниц всего: index, winkel, over-ons, contact + 404)

### winkel.html — «De winkel» (витрина + демо-корзина)
- **Hero-фильм** `film-winkel.mp4` (W1+W2, 250vh): 3 главы — `Op de plank.` / `Brood erbij.` / `En wat je verder zoekt.`; HUD `PLANK · 01 / 03`.
- **Плашка честности сверху каталога** (стекло, моно): `Voorbeeldassortiment — door de eigenaar aan te vullen. Geen prijzen: die hoor je in de winkel.`
- **Каталог** — фильтр-вкладки категорий (Brood & gebak · Vleeswaren · Zuivel · Potten & blikken · Snoep & koek · Dranken) + чипы smaakkompas (zuur · zoet · hartig · vers) + поиск. Карточки товаров = кропы K13 (флэт-лей 3×2) + K8/K9 (object-position), у каждой: Young Serif название (общее, без бренда: «Roggebrood», «Ogórki kiszone», «Twaróg (kwark)», «Gerookte worst», «Krówki (karamel)», «Maanzaadbrood»…), 1 строка описания, моно `prijs in de winkel`, степпер количества, кнопка `In mandje` (полёт миниатюры в иконку корзины в шапке — иконка с числом на всех страницах, localStorage try/catch). Подпись `Sfeerbeeld · voorbeeld` на каждом фото.
- **Корзина-панель (drawer)** → оформление демо: `Afhalen` (по умолчанию) / `Bezorgen — alleen als de winkel dit aanbiedt` (disabled с пометкой), имя, телефон, желаемый день/время (свободное поле, без «open»-логики), примечание. Итог: число позиций, `Totaal: prijzen volgen in de winkel`. Кнопки: `Betalen met iDEAL — demo` (открывает честный модал «Dit is een ontwerpvoorstel: er wordt niets betaald of verstuurd») и **«Boodschappenbriefje»** (интерактив 3): собирает список текстом — `Kopieer` / `Bel de winkel` (tel:) / `Stuur via WhatsApp` (с пометкой «nog te bevestigen»).
- Блок-заглушка (пунктир `--glass-b`): «Hier komen foto's van de echte schappen van De Poolse Winkel Igor.»
- Финал общий.

### over-ons.html — «Over de winkel»
- **Hero-фильм** `film-over.mp4` (O1, 200vh): 2 главы — `Een gewone straat in Waalwijk.` / `En daar, achter het raam: potten.` Подпись `Sfeerbeeld — niet de echte gevel`.
- **J «Een stukje Polen om de hoek»** (фон `--paper`): 3 абзаца о том, что такое польский магазин в квартале (общее), без истории владельца.
- **Линия-процесс (SVG, рисуется по скроллу, точка-пузырёк `--accent` едет):** `binnenlopen → rondkijken → vragen wat er is → afrekenen → smacznego` — не услуги, а путь покупателя (общий).
- **«Het verhaal van Igor» — честная заглушка** (тёмная лента `--dark`): заголовок + 3 пустые «этикетки банок» с вопросами `Sinds wanneer?` · `Wie staat er achter de toonbank?` · `Wat mag je niet missen?` и подпись `Dit vertelt de eigenaar zelf — wordt ingevuld na overleg.` Стоп-кадр K11 рядом.
- Финал общий.

### contact.html — «Contact»
- **Hero** loop-contact.mp4 (K12, тюль колышется) + h1 `Kom langs.` + PL-акцент `Zapraszamy!`.
- **Стеклянная сетка:** Adres (`Mendelssohnstraat 96, Waalwijk`) · Telefoon (`06 30 56 21 99`, tel:) · WhatsApp (`nog te bevestigen`) · Openingstijden (`volgen — bel gerust even`) · Route (Google Maps).
- **Карта:** светлая SVG-схема кодом (без тайлов): точка-банка `--accent` + подпись «Mendelssohnstraat 96» + кнопка «Open in Google Maps». Улицы-соседи не рисовать «по памяти» — только абстрактная сетка кварталов + точка (честно: «schematisch»).
- Короткий FAQ (COPY): «Kan ik vooraf bestellen?», «Hoe laat zijn jullie open?», «Spreken jullie Nederlands?» — все ответы честные: «Bel even, dan hoor je het meteen».
- Финал общий.

### 404.html — K2 (огурцы в банке) + «Deze pagina staat niet op de plank.» + ссылки.

## 6. Переход между страницами — «deksel»
Круглая ирис-маска из центра экрана закрывается, как крышка банки: внешнее кольцо `--dark` с тонкими радиальными «рисками» (как насечка металлической крышки) поворачивается на 90° по часовой, в центре название страницы Young Serif (`winkel.` / `over de winkel.` / `contact.` / `home.`), затем раскрывается против часовой на новой странице. Вперёд по меню — по часовой, назад — против. `prefers-reduced-motion` → fade 200 ms. На телефоне без поворота, только ирис.

## 7. Движение на всех секциях (кодом, только когда видно)
Пылинки в солнечном луче (canvas, paper + 1/10 accent), пузырьки в рассоле (главы 4–6, портал, pekelklok), падающие горчичные зёрна (гл.3), блик по стеклу банки раз в ~7 с (CSS-маска по кадру), «дыхание» стоп-кадров (scale 1→1.03), параллакс K7/K12 от мыши, заголовки по словам, кнопки с бликом, стеклянные плашки со свечением за курсором, тюль (лёгкий SVG-шум) на contact. Плёночное зерно 4–5 % + виньетка — поверх всех фильмов. Lenis-инерция.

---

## 8. ПРОМПТЫ — Higgsfield `gpt_image_2_6` (13 кадров + 1 резерв = 14, лимит соблюдён)

### ANCHOR (дословно в начало K1–K6; для K7–K13 — первая строка ANCHOR + своя сцена)
```
ANCHOR: Cinematic film still, bright airy natural light, soft morning sun through a window, palette of pale cucumber green #DEEBBF and garlic-white #F6F8EA tones, dark dill green #25401E only in small details, mustard-gold #E39B12 sunlight glints, anamorphic 35mm look, light atmospheric haze, fine film grain, photoreal, 16:9. Scene: one tall clear cylindrical glass preserving jar with no label and no print stands on a pale limed-oak windowsill inside a bright window; a sheer white linen curtain hangs on the left; through the glass, a soft out-of-focus green garden and pale sky; sunlight comes from the upper right and casts long soft shadows across the sill. On the sill, always in the same place to the right of the jar: one garlic bulb, a sprig of fresh dill and a small white enamel dish of yellow mustard seeds. Camera at sill height, 35mm, gentle depth of field. No people, no hands, no tools, no text, no letters, no labels, no logos, no watermark.
```

| # | ID / файл | Где | Референс (medias) | Промпт (после ANCHOR) | Пустое место под текст |
|---|---|---|---|---|---|
| 1 | **K1** `kf/k1-pot.webp` | Home гл.1, hero-poster | — (мастер, ПЕРВЫМ) | `Wide composition: the empty clean jar stands at about 38% from the left, occupying about 40% of the frame height; morning light is still cool and slightly blue-green; the sky in the upper right window pane is calm and bright.` | небо справа вверху |
| 2 | **K2** `kf/k2-komkommers.webp` | гл.2, 404 | K1 | `Same scene, same light, same sill objects as the reference. The camera has moved about 10% closer. The jar is now tightly packed with small firm fresh dark-green pickling cucumbers standing upright side by side, filling it to the shoulder. Nothing else changed.` | тюль слева |
| 3 | **K3** `kf/k3-dille.webp` | гл.3, J1 стоп-кадр | K2 | `Same scene and light as the reference, camera another 10% closer and slightly lower, the jar now at about 52% from the left and 60% of the frame height. On top of and between the upright cucumbers: two umbrella heads of flowering dill, peeled garlic cloves, one large horseradish leaf tucked along the inside of the glass, and yellow mustard seeds scattered between the cucumbers. Sunlight warms the curtain on the left.` | стена/тюль слева вверху |
| 4 | **K4** `kf/k4-pekel.webp` | гл.4, J1 стоп-кадр | K3 | `Same scene, framing and objects as the reference. A thin clear stream of water pours straight down into the jar from above the top edge of the frame (its source is out of frame); the jar is half full of clear brine with small air bubbles rising; sunlight refracts through the water and throws bright rippling caustics onto the sill; a few droplets sparkle mustard-gold.` | слева вверху |
| 5 | **K5** `kf/k5-deksel.webp` | гл.5, poster F5, pekelklok-старт | K4 | `Same scene and framing as the reference, camera about 3% further back. No more water stream. The jar is full to the neck with clear brine and closed with a plain silver metal twist lid without any print; a faint mist of condensation on the upper glass; full bright midday light.` | справа вверху |
| 6 | **K6** `kf/k6-geduld.webp` | гл.6, портал, pekelklok-финиш | K5 | `Same jar, lid, sill objects and camera as the reference, but now late golden-hour light: warm low amber sun from the right, long golden shadows across the sill, the garden outside glowing. The cucumbers inside have turned an olive green, the brine is slightly cloudy and glows softly gold, tiny bubbles cling to the glass. Same composition.` | слева вверху |
| 7 | **K7** `kf/k7-plank.webp` | Home act 2, winkel W1 start | K6 (та же банка) | `First line of ANCHOR. Frontal centred symmetric view of a sunlit pale-wood shop shelf unit in a small neighbourhood grocery: on the middle shelf a neat row of unlabeled glass jars (olive pickles, red beet slices, mushrooms, dark fruit preserve), the same olive-pickle jar from the reference standing exactly in the centre; soft morning window light from the left, pale green-white walls. No labels, no price tags, no brands, no text, no people, no hands.` | верхняя полка/стена |
| 8 | **K8** `kf/k8-brood.webp` | winkel W1 end / W2 start, кропы каталога | K7 | `Same shelf unit, light and camera height as the reference, the camera has moved sideways to the right by about one third of the frame: now in view a lower shelf with round dark rye loaves and a braided poppy-seed loaf resting on a natural linen cloth, a few plain unprinted brown paper bags folded beside them; the jar row is still partly visible at the left edge.` | стена сверху |
| 9 | **K9** `kf/k9-toonbank.webp` | winkel W2 end, кропы каталога | K8 | `Same shop, light and camera height as the reference, camera moved further right and slightly closer: the end of a small wooden counter with a ring of smoked sausage on brown paper, a bowl of crumbly white farmer's cheese, a small glass dish of caramel fudge sweets wrapped in plain unprinted paper, and a jar of golden honey; the rye bread shelf just visible at the left edge.` | слева вверху |
| 10 | **K10** `kf/k10-straat.webp` | over-ons O1 start | K1 (тон, свет) | `First line of ANCHOR. A quiet Dutch residential street in Noord-Brabant on a sunny morning: low red-brown brick terraced houses with white window frames, young trees, a clean brick-paved pavement, two bicycles parked against a wall, soft long shadows; about 30 metres ahead on the right a small shop window in the ground floor of a brick house with glass jars and a pot of dill visible behind the glass. Low camera at pedestrian eye level, one-point perspective. No readable signs, no house numbers, no text, no logos, no people, no cars.` | небо сверху |
| 11 | **K11** `kf/k11-raam.webp` | over-ons O1 end, «Het verhaal»-кадр | K10 | `Same street, light and camera height as the reference, the camera has walked forward and now stands about 4 metres from the same shop window, slightly angled: behind the clean glass a pale-wood shelf with unlabeled glass jars of pickles and preserves and a potted dill plant on the inner sill; the shop door beside it stands ajar; sunlight reflections on the glass. No readable signs, no text, no logos, no people.` | кирпичная стена слева |
| 12 | **K12** `kf/k12-uitzicht.webp` | финалы всех страниц, contact loop | K6 (банка) + K11 (улица) | `First line of ANCHOR. Inside the shop looking out: the same olive-pickle jar with silver lid from the reference stands on a pale-wood inner windowsill as a soft silhouette against the light, a sheer linen curtain on the right; through the window a bright, softly out-of-focus sunny Dutch brick street with trees. Strong backlight, glowing haze, dust motes in the sunbeam. Jar at about 30% from the left, lower third. No people, no text, no logos.` | правая половина окна |
| 13 | **K13** `kf/k13-voorbeeld.webp` | winkel hero-still, 6 кропов каталога, over-ons | K9 (тон) | `First line of ANCHOR. Top-down flat-lay on a natural linen cloth in soft daylight, six items laid out in a loose 3 by 2 grid with generous space between them so each can be cropped separately: a round dark rye loaf, an open jar of olive pickles with dill, a ring of smoked sausage, a bowl of white farmer's cheese, a small heap of caramel fudge sweets in plain unprinted paper wrappers, a braided poppy-seed loaf. No labels, no brands, no text, no hands.` | — (каталог) |
| 14 | **R** резерв | перегенерация самого проблемного кадра (скорее всего K4 — струя/вода) | — | — | — |

**Подписи:** K1–K13 → `Sfeerbeeld` (K13 и кропы каталога: `Sfeerbeeld · voorbeeld`). Людей нет — `Voorbeeldbeeld` не нужен; если позже появится кадр с человеком — подпись `Voorbeeldbeeld` обязательна.
**Порядок генерации (цепочка):** K1 → K2 → K3 → K4 → K5 → K6 → K7 → K8 → K9 → K13; K10 (ref K1) → K11; K12 (ref K6 + K11). Проверка каждого кадра глазами: банка та же (форма, высота, без этикетки), предметы на подоконнике на месте, нет рук/инструментов/текста; у K1–K6 подоконник и окно совпадают (допуск ±3 %), иначе выровнять кропом до LTX.
**Мобильные кропы:** 1080×1920 по центру банки (K1 x 38 %, K2–K6 x 55 %, K7 центр, K12 x 30 %).

## 9. Что нужно от клиента (заменит заглушки)
Фото магазина/полок/фасада, реальный ассортимент и категории, часы, подтверждение WhatsApp, индекс, история «Over ons», логотип — см. BRIEF «Открытые вопросы».
