# TYPE — De Poolse Winkel Igor (Waalwijk)

Роль: type-director · вход: BRIEF.md, PALETTE.md («Ogórek w słońcu») · формула SCROLL FILM §2.6: пара «журнал» = антиква для глав + моно для HUD.

Pair: **Young Serif 400** (главы, заголовки) + **Work Sans 400** (абзацы) + **IBM Plex Mono 500** (HUD, кнопки, подписи, корзина). Ровно 3 начертания.

## Почему так
- **Young Serif** — мягкая, тяжеловатая «домашняя» антиква с круглыми каплями и короткими засечками (в FONTS.md — «мягкий жирный серифный → Young Serif»). Похожа на надписи на старых этикетках банок и вывесках продуктовых лавок — ровно характер «соседского польского магазина», без корпоративности. На светло-зелёном фоне укропным цветом читается как печать на бумажной этикетке.
- **Work Sans 400** — гротеск с широкими пропорциями и высокой x-высотой, хорошо читается на телефоне в длинных абзацах журнала и в каталоге.
- **IBM Plex Mono 500** — HUD фильма («kiszenie · 03 / 06»), подписи «Voorbeeldbeeld», цифры в корзине (tabular-nums), кнопки капсом с трекингом — как ярлык/накладная магазина.
- **Отличие от Warta** (тот же город и ниша): Warta = Sora 300 + Figtree, тонкий строчный гротеск, ночь. Igor = тёплая антиква с засечками + моно-ярлыки, день. Визуально другой сайт с первого кадра.
- Не повторяется с `journal/fonts.md`: Playfair, Pinyon, Inter, Space Mono, Bricolage, Great Vibes, Urbanist, Sora, Figtree, Outfit, Manrope, Plus Jakarta Sans, Albert Sans, Jost, Hanken Grotesk, Red Hat Display, Instrument Sans, Fraunces, Schibsted Grotesk, DM Mono — ни одного совпадения. Запрещённые как главный (Inter, Roboto, Poppins, Montserrat, Playfair) — не используются.

## Проверка Google Fonts + польская диакритика (19.11.2026, css2 API)
- Все три шрифта есть на Google Fonts; у всех есть подмножество **latin-ext** (U+0100–02BA).
- Запрос `css2?family=…&text=ąęłśżźćńóĄŁŻ` вернул файл шрифта для каждого из трёх → глифы польских букв есть.
- Builder обязан визуально проверить строку: `Zapraszamy! Smacznego. Ogórki kiszone, słoik, półka, żurek, ćwikła, Dzień dobry — één, café, ‘s-Hertogenbosch`.

## Google Fonts
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@500&family=Work+Sans:wght@400&family=Young+Serif&display=swap" rel="stylesheet">
```
(или self-host 3 woff2 latin + latin-ext в `assets/fonts/`, `font-display:swap`).

## Tokens & scale
```css
:root{
  --f-display:'Young Serif',Georgia,serif;
  --f-body:'Work Sans',system-ui,sans-serif;
  --f-mono:'IBM Plex Mono',ui-monospace,monospace;
}
body{font:400 clamp(17px,.9vw + 12.5px,19px)/1.62 var(--f-body);color:var(--dark)}
h1,h2,h3,.ftitle h2{font-family:var(--f-display);font-weight:400;margin:0;text-transform:none}
.ftitle h2{font-size:clamp(3rem,7.2vw,7.5rem);line-height:.98;letter-spacing:-.025em}   /* строка-глава поверх фильма, 2–6 слов с точкой */
h1{font-size:clamp(2.8rem,6.4vw,6.4rem);line-height:1;letter-spacing:-.022em}           /* hero внутренних страниц */
h2{font-size:clamp(2.1rem,4.4vw,4.4rem);line-height:1.04;letter-spacing:-.018em}
h3{font-size:clamp(1.35rem,2vw,1.9rem);line-height:1.15;letter-spacing:-.01em}
.bigword{font:400 clamp(7rem,20vw,22rem)/.85 var(--f-display);letter-spacing:-.03em;color:var(--dark);opacity:.07} /* польское слово за объектом */
.lead{font:400 clamp(1.08rem,1.25vw,1.32rem)/1.55 var(--f-body);color:var(--muted)}
.ftitle p,.cap{font:500 .78rem/1.35 var(--f-mono);letter-spacing:.14em;text-transform:uppercase;color:var(--muted)}
.hud,.fcount{font:500 .72rem/1 var(--f-mono);letter-spacing:.16em;text-transform:uppercase;font-variant-numeric:tabular-nums}
.btn,.nav a,.chip{font:500 .8rem/1 var(--f-mono);letter-spacing:.12em;text-transform:uppercase}
.price,.qty,.cart-count{font:500 1rem/1 var(--f-mono);font-variant-numeric:tabular-nums}
.pl{font-family:var(--f-display);font-style:normal} /* польские акценты: «Zapraszamy!» — тем же Young Serif, не скриптом */
```

## Правила
- Главы фильма — Young Serif, с заглавной только первое слово, короткая фраза с точкой: «Eerst de pot.», «Dan de dille.», «Zout water, verder niets.».
- Польские слова (большие слова за объектом, акценты) — тем же Young Serif; рукописных шрифтов нет.
- Капс — только моно (HUD, кнопки, подписи) с трекингом .12–.16em. Никакого капса антиквой.
- Абзацы ≤ 62ch; на телефоне body не меньше 17px; HUD не меньше 11px.
- Курсив не подключаем (Young Serif без italic) — выделение только весом соседнего моно или цветом `--dark` vs `--muted`.

Journal row: `| de-poolse-winkel-igor (в работе) | Young Serif 400 | Work Sans 400, IBM Plex Mono 500 |`
